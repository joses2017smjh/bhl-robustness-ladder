from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))
from bhl_robust.eval.replay_gate import main
if __name__ == '__main__':
    raise SystemExit(main())
